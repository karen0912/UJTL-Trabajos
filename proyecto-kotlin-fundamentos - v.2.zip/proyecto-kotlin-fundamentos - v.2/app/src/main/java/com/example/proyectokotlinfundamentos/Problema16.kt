package com.example.proyectokotlinfundamentos

// Nombre:
// Fecha:
// Descripción: Solución del Problema 16 de la guía de Kotlin fundamentos

// Función principal
fun main() {
    problema16()
}

// Función que debe desarrollar la lógica para la solución del problema
fun problema16() {


        // Leer las entradas
        val n = readLine()!!.toInt()
        val m = readLine()!!.toInt()
        val k = readLine()!!.toInt()

        // Calcular el número total de porciones
        val totalPorciones = n * m

        // Verificar si se puede dividir la barra en dos partes con exactamente k porciones
        if (k in 1 until totalPorciones && (k % n == 0 || k % m == 0)) {
            println("SÍ")
        } else {
            println("NO")
        }
    }


