package com.example.proyectokotlinfundamentos

// Nombre:
// Fecha:
// Descripción: Solución del Problema 5 de la guía de Kotlin fundamentos

// Función principal
fun main() {
    problema5()
}

// Función que debe desarrollar la lógica para la solución del problema
fun problema5() {

        println("e:")
        val e = readLine()!!.toInt()

        println("m:")
        val m = readLine()!!.toInt()

        val manzanasPorEstudiante = m / e
        val manzanasEnCanasta = m % e

        println("Cada estudiante recibirá: $manzanasPorEstudiante manzanas.")
        println("Quedarán en la canasta: $manzanasEnCanasta manzanas.")
    }


