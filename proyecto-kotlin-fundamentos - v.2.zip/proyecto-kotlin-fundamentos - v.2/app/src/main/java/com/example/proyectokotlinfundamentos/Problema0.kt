package com.example.proyectokotlinfundamentos

// Nombre:
// Fecha:
// Descripción: Solución del Problema 0 de la guía de Kotlin fundamentos

// Función principal
fun main() {
    problema0()
}

// Función que debe desarrollar la lógica para la solución del problema
fun problema0() {
    // Desarrolle aquí la lógica

}