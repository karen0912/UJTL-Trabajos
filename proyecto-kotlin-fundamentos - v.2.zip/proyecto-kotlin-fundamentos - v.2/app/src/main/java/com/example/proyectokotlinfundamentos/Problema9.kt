package com.example.proyectokotlinfundamentos

// Nombre:
// Fecha:
// Descripción: Solución del Problema 9 de la guía de Kotlin fundamentos

// Función principal
fun main() {
    problema9()
}

// Función que debe desarrollar la lógica para la solución del problema
fun problema9() {


        println("Dame num1:")
        val num1 = readLine()!!.toInt()

        println("Dame num2:")
        val num2 = readLine()!!.toInt()

        if (num1 > 2 * num2) {
            println("Wow!")
        } else {
            println("Aburrido!")
        }
    }


