package com.example.proyectokotlinfundamentos

// Nombre:
// Fecha:
// Descripción: Solución del Problema 3 de la guía de Kotlin fundamentos

// Función principal
fun main() {
    problema3()
}

// Función que debe desarrollar la lógica para la solución del problema
fun problema3() {

        println("Ingresa la asignatura:")
        val asignatura = readLine()!!

        println("Ingresa nota primer corte:")
        val nota1 = readLine()!!.toDouble()

        println("Ingresa nota segundo corte:")
        val nota2 = readLine()!!.toDouble()

        println("Ingresa nota tercer corte:")
        val nota3 = readLine()!!.toDouble()

        val definitiva = (nota1 * 0.33) + (nota2 * 0.33) + (nota3 * 0.34)

        println("Asignatura: $asignatura")
        println("Definitiva: %.3f".format(definitiva))

    }
