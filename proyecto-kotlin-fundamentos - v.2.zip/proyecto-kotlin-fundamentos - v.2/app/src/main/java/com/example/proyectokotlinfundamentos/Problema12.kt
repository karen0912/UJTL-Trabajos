package com.example.proyectokotlinfundamentos

// Nombre:
// Fecha:
// Descripción: Solución del Problema 12 de la guía de Kotlin fundamentos

// Función principal
fun main() {
    problema12()
}

// Función que debe desarrollar la lógica para la solución del problema
fun problema12() {

        // Solicitar los tres números al usuario
        println("Dame num1:")
        val num1 = readLine()!!.toInt()
        println("Dame num2:")
        val num2 = readLine()!!.toInt()
        println("Dame num3:")
        val num3 = readLine()!!.toInt()

        // Comparar los números
        when {
            num1 == num2 && num2 == num3 -> println(3) // Si todos son iguales
            num1 == num2 || num2 == num3 || num1 == num3 -> println(2) // Si dos son iguales
            else -> println(0) // Si todos son diferentes
        }
    }


