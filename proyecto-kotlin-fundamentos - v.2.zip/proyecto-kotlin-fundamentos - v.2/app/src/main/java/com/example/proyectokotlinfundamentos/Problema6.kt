package com.example.proyectokotlinfundamentos

// Nombre:
// Fecha:
// Descripción: Solución del Problema 6 de la guía de Kotlin fundamentos

// Función principal
fun main() {
    problema6()
}

// Función que debe desarrollar la lógica para la solución del problema
fun problema6() {

        println("Dame un número entero:")
        val numero = readLine()!!.toInt()

        val suma = (numero / 100) + (numero / 10 % 10) + (numero % 10)

        println("La suma de los dígitos del número $numero es igual a $suma.")
    }

