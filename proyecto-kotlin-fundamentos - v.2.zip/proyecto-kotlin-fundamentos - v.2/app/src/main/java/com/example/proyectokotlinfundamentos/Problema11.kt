package com.example.proyectokotlinfundamentos

// Nombre:
// Fecha:
// Descripción: Solución del Problema 11 de la guía de Kotlin fundamentos

// Función principal
fun main() {
    problema11()
}

// Función que debe desarrollar la lógica para la solución del problema
fun problema11() {

        println("Dame el presupuesto:")
        val presupuesto = readLine()!!.toInt()
        println("Dame el valor de la comida:")
        val comida = readLine()!!.toInt()
        println("Dame el valor de la electricidad:")
        val electricidad = readLine()!!.toInt()
        println("Dame el valor del internet:")
        val internet = readLine()!!.toInt()
        println("Dame el valor del arriendo:")
        val arriendo = readLine()!!.toInt()

        if (presupuesto < comida + electricidad + internet + arriendo) {
            println("Rayos estoy quebrado(a)!")
        } else {
            println("Vamos melos!")
        }
    }


