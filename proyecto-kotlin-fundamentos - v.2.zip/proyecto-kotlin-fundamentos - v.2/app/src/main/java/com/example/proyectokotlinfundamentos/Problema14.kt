package com.example.proyectokotlinfundamentos

// Nombre:
// Fecha:
// Descripción: Solución del Problema 14 de la guía de Kotlin fundamentos

// Función principal
fun main() {
    problema14()
}

// Función que debe desarrollar la lógica para la solución del problema
fun problema14() {

        println("Dame num1:")
        val num1 = readLine()!!.toInt()
        println("Dame num2:")
        val num2 = readLine()!!.toInt()
        println("Dame num3:")
        val num3 = readLine()!!.toInt()

        // Comprobamos si hay un empate o si uno es el mayor
        if (num1 == num2 && num2 == num3) {
            println(num1)
        } else if (num1 >= num2 && num1 >= num3) {
            if (num1 == num2 || num1 == num3) {
                println("Hay un empate!")
            } else {
                println(num1)
            }
        } else if (num2 >= num1 && num2 >= num3) {
            if (num2 == num3) {
                println("Hay un empate!")
            } else {
                println(num2)
            }
        } else {
            println(num3)
        }
    }

