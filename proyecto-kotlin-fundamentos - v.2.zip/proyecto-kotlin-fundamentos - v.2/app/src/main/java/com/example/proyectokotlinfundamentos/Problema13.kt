package com.example.proyectokotlinfundamentos

// Nombre:
// Fecha:
// Descripción: Solución del Problema 13 de la guía de Kotlin fundamentos

// Función principal
fun main() {
    problema13()
}

// Función que debe desarrollar la lógica para la solución del problema
fun problema13() {

        println("Dame un numero:")
        val num = readLine()!!.toInt()

        // Extraemos los dígitos del número
        val d1 = num / 100 // primer dígito
        val d2 = (num / 10) % 10 // segundo dígito
        val d3 = num % 10 // tercer dígito

        // Comprobamos si los dígitos están en orden ascendente
        if (d1 < d2 && d2 < d3) {
            println("SÍ")
        } else {
            println("NO")
        }

}