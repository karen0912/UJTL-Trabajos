package com.example.proyectokotlinfundamentos

// Nombre:
// Fecha:
// Descripción: Solución del Problema 8 de la guía de Kotlin fundamentos

// Función principal
fun main() {
    problema8()
}

// Función que debe desarrollar la lógica para la solución del problema
fun problema8() {

        println("Dame la base:")
        val base = readLine()!!.toInt()

        println("Dame el exponente:")
        val exponente = readLine()!!.toInt()

        val resultado = Math.pow(base.toDouble(), exponente.toDouble()).toInt()

        if (resultado > 5000) {
            println("Muy grande.")
        } else {
            println("Números óptimos.")
        }

    }