package com.example.proyectokotlinfundamentos

// Nombre:
// Fecha:
// Descripción: Solución del Problema 4 de la guía de Kotlin fundamentos

// Función principal
fun main() {
    problema4()
}

// Función que debe desarrollar la lógica para la solución del problema
fun problema4() {

        println("Ingresa valor artículo 1:")
        val articulo1 = readLine()!!.toDouble()

        println("Ingresa valor artículo 2:")
        val articulo2 = readLine()!!.toDouble()

        println("Ingresa valor artículo 3:")
        val articulo3 = readLine()!!.toDouble()

        val valorNeto = articulo1 + articulo2 + articulo3
        val valorTotal = valorNeto * 1.18 // Se suma el 18% de impuesto

        println("Valor neto: $valorNeto")
        println("Valor total: $valorTotal")
    }


