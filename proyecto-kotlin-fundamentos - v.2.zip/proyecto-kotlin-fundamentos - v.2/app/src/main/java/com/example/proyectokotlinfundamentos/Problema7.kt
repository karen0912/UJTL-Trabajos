package com.example.proyectokotlinfundamentos

// Nombre:
// Fecha:
// Descripción: Solución del Problema 7 de la guía de Kotlin fundamentos

// Función principal
fun main() {
    problema7()
}

// Función que debe desarrollar la lógica para la solución del problema
fun problema7() {
        println("¿Cuántos sonidos del grillo escuchaste por minuto?")
        val N = readLine()!!.toInt()

        if (N < 0) {
            println("Seguro investigador, ¿un grillo puede hacer ese número de sonidos?")
        } else {
            val T = N / 4.0 + 40.0
            println("Dados los sonidos del grillo, la temperatura es de %.2f °F.".format(T))
        }
    }


