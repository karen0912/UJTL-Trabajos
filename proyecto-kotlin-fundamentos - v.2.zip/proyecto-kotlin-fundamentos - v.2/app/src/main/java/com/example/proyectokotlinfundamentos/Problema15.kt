package com.example.proyectokotlinfundamentos

// Nombre:
// Fecha:
// Descripción: Solución del Problema 15 de la guía de Kotlin fundamentos

// Función principal
fun main() {
    problema15()
}

// Función que debe desarrollar la lógica para la solución del problema
fun problema15() {

        println("Dame un numero de 4 cifras:")
        val numero = readLine()!!.toInt()

        // Convertimos el número a un String y lo comparamos con su reverso
        if (numero.toString() == numero.toString().reversed()) {
            println("SÍ")
        } else {
            println("NO")
        }
    }


